import React, { useState } from 'react';

function App() {
  const [isUserRegistered, setIsUserRegistered] = useState(false);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [userRegisteredMessage, setUserRegisteredMessage] = useState('');
  const [taskRegisteredMessage, setTaskRegisteredMessage] = useState('');

  const handleUserRegistration = () => {
    setIsUserRegistered(true);
    setShowTaskForm(true);
  };

  const handleTaskRegistration = () => {
  };

  return (
    <div>
      {!showTaskForm && (
        <div className="registration-form-container">
          <h2 className="center">Cadastro de Usuário</h2>
          {userRegisteredMessage && (
            <p className="success">{userRegisteredMessage}</p>
          )}
          <form className="registration-form">
            <div className="field">
              <label for="username">Nome de Usuário:</label>
              <input type="text" id="username" name="username" />
            </div>
            <div className="field">
              <label for="email">E-mail:</label>
              <input type="email" id="email" name="email" />
            </div>
            <div className="field">
              <label for="password">Senha:</label>
              <input type="password" id="password" name="password" />
            </div>
            <button type="submit" onClick={handleUserRegistration}>Cadastrar Usuário</button>
          </form>
        </div>
      )}

      {showTaskForm && (
        <div className="task-form-container">
          <h2 className="center">Cadastro de Tarefa</h2>
          {taskRegisteredMessage && (
            <p className="success">{taskRegisteredMessage}</p>
          )}
          <form className="task-form">
            <div className="field">
              <label for="task-name">Nome da Tarefa:</label>
              <input type="text" id="task-name" name="task-name" />
            </div>
            <div className="field">
              <label for="task-description">Descrição da Tarefa:</label>
              <textarea id="task-description" name="task-description"></textarea>
            </div>
            <div className="field">
              <label for="task-priority">Status:</label>
              <select id="task-priority" name="task-priority">
              <option value="baixa">Selecionar...</option>
                <option value="baixa">Concluída</option>
                <option value="media">Em Andamento</option>
                <option value="alta">Pendente</option>
              </select>
            </div>
            <button type="submit" onClick={handleTaskRegistration}>Cadastrar Tarefa</button>
          </form>
        </div>
      )}
    </div>
  );
}

export default App;